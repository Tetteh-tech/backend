<?php
passthru('php artisan storage:link');
echo "symlink created";
?>
